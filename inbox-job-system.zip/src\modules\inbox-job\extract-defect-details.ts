const NOISE_PREFIXES = [
  /^hi[, ]*/iu,
  /^hello[, ]*/iu,
  /^dear\b[^\n,]*,?\s*/iu,
  /^please\s+(note|be\s+aware)\s+that\s+/iu,
];

export function extractDefectDetails(body: string, subject = ''): string {
  const cleanedBody = body
    .replace(/\r\n/gu, '\n')
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line.length > 0)
    .join(' ')
    .replace(/\s+/gu, ' ')
    .trim();

  if (cleanedBody === '') {
    return subject.trim() || 'Vehicle defect reported';
  }

  let details = cleanedBody;
  for (const prefix of NOISE_PREFIXES) {
    details = details.replace(prefix, '');
  }

  // Prefer a concise defect sentence; keep enough context for the workshop.
  if (details.length > 280) {
    details = `${details.slice(0, 277).trim()}...`;
  }

  return details.trim() || subject.trim() || 'Vehicle defect reported';
}

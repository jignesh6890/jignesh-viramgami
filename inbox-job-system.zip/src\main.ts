import { createProhireClient } from './integrations/prohire/prohire.client.js';
import { logger } from './common/observability/logger.js';
import { createProcessInboxService } from './modules/inbox-job/process-inbox.service.js';
import { env } from './config/env.js';
import { startMockServer } from './mock-server/server.js';

async function main(): Promise<void> {
  const isDemo = process.argv.includes('--demo');
  let baseUrl = env.API_BASE_URL.replace(/\/$/u, '');
  let mockServer: Awaited<ReturnType<typeof startMockServer>> | null = null;

  if (isDemo) {
    mockServer = await startMockServer(env.MOCK_SERVER_PORT);
    baseUrl = `http://127.0.0.1:${env.MOCK_SERVER_PORT}/api/v1`;
  }

  logger.info(
    {
      baseUrl,
      mode: isDemo ? 'demo' : 'live',
    },
    'Starting Inbox → Job pipeline',
  );

  try {
    const client = createProhireClient({
      baseUrl,
      apiKey: env.API_KEY,
      timeoutMs: env.HTTP_TIMEOUT_MS,
    });

    const service = createProcessInboxService(client);
    const result = await service.run();

    logger.info(
      {
        classified: result.classifications.length,
        jobsCreated: result.jobsCreated,
        jobsSkipped: result.jobsSkipped,
        classifications: result.classifications,
        submitResponse: result.submitResponse,
      },
      'Pipeline completed',
    );

    console.log('\n=== Inbox → Job results ===');
    for (const item of result.classifications) {
      console.log(`- email_id=${String(item.email_id)} type=${item.type}`);
    }
    console.log(`Jobs created: ${result.jobsCreated}`);
    console.log(`Jobs skipped: ${result.jobsSkipped}`);
    console.log('Submit response:', JSON.stringify(result.submitResponse, null, 2));
  } finally {
    if (mockServer !== null) {
      await new Promise<void>((resolve, reject) => {
        mockServer.close((error) => {
          if (error) {
            reject(error);
            return;
          }
          resolve();
        });
      });
    }
  }
}

main().catch((error: unknown) => {
  logger.error({ err: error }, 'Pipeline failed');
  console.error(error);
  process.exitCode = 1;
});

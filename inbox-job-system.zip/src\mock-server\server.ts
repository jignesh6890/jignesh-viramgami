import { createServer } from 'node:http';
import { pathToFileURL } from 'node:url';

import express from 'express';

import { env } from '../config/env.js';
import { logger } from '../common/observability/logger.js';
import type {
  ClassificationResult,
  CreateProhireJobPayload,
  InboxEmail,
} from '../integrations/prohire/prohire.types.js';

const SAMPLE_EMAILS: InboxEmail[] = [
  {
    id: 101,
    from: 'yard@highlift.example',
    to: 'defects@broker.example',
    subject: 'Faulty indicator on van GK20AOR',
    body: 'Hi, the near-side indicator on our van registration GK20AOR is faulty and not flashing. Please raise a job.',
    timestamp: '2026-07-23T09:00:00.000Z',
  },
  {
    id: 102,
    from: 'ops@fleetco.example',
    to: 'defects@broker.example',
    subject: 'Issue with registration FG22ABC',
    body: 'The wing mirror is cracked on FG22ABC and needs replacing before the next hire.',
    timestamp: '2026-07-23T09:05:00.000Z',
  },
  {
    id: 103,
    from: 'accounts@acme.example',
    to: 'sales@broker.example',
    subject: 'Quote for additional vans',
    body: 'Could you send pricing and availability for two extra 3.5t vans next month?',
    timestamp: '2026-07-23T09:10:00.000Z',
  },
  {
    id: 104,
    from: 'driver@site.example',
    to: 'support@broker.example',
    subject: 'Opening hours enquiry',
    body: 'What are your depot opening hours and where are you located?',
    timestamp: '2026-07-23T09:15:00.000Z',
  },
  {
    id: 105,
    from: 'noreply@deals.example',
    to: 'inbox@broker.example',
    subject: 'Limited time special offer – 40% discount',
    body: 'Act now! Click here to claim your promo code. Unsubscribe at any time.',
    timestamp: '2026-07-23T09:20:00.000Z',
  },
  {
    id: 106,
    from: 'news@insurancemarketing.example',
    to: 'inbox@broker.example',
    subject: 'July newsletter: fleet tips',
    body: 'This month in our newsletter: marketing webinars and free trial extensions.',
    timestamp: '2026-07-23T09:25:00.000Z',
  },
  {
    id: 107,
    from: 'unknown@spam.example',
    to: 'inbox@broker.example',
    subject: '',
    body: '',
    timestamp: '2026-07-23T09:30:00.000Z',
  },
  {
    id: 108,
    from: 'bot@noise.example',
    to: 'inbox@broker.example',
    subject: 'asdf',
    body: '%%%%####@@@@ ~~~~ qqqqqqqqqqqqqqqqqqq',
    timestamp: '2026-07-23T09:35:00.000Z',
  },
  {
    id: 109,
    from: 'workshop@partner.example',
    to: 'defects@broker.example',
    subject: 'Brake warning light – BX19 KLM',
    body: 'Please note that vehicle BX19KLM has a brake warning light on and the pedal feels soft.',
    timestamp: '2026-07-23T09:40:00.000Z',
  },
  {
    id: 110,
    from: 'hr@candidate.example',
    to: 'careers@broker.example',
    subject: 'Application for office admin role',
    body: 'I would like information about the admin vacancy and salary. Can you help?',
    timestamp: '2026-07-23T09:45:00.000Z',
  },
];

const CUSTOMERS: Record<
  string,
  {
    customer_name: string;
    address: string;
    phone: string;
    vehicle_reg: string;
    vehicle_type: string;
  }
> = {
  GK20AOR: {
    customer_name: 'High Lift Plant Hire',
    address: 'Unit 3, Trade Park, Maidstone, ME15 6YZ',
    phone: '01622 555010',
    vehicle_reg: 'GK20AOR',
    vehicle_type: '3.5t Panel Van',
  },
  FG22ABC: {
    customer_name: 'Coastal Logistics Ltd',
    address: '12 Harbour Way, Dover, CT17 9AB',
    phone: '01304 555220',
    vehicle_reg: 'FG22ABC',
    vehicle_type: 'Luton Van',
  },
  BX19KLM: {
    customer_name: 'Kent Site Services',
    address: '44 Quarry Lane, Sittingbourne, ME10 3CD',
    phone: '01795 555330',
    vehicle_reg: 'BX19KLM',
    vehicle_type: 'Tipper',
  },
};

function requireApiKey(
  req: express.Request,
  res: express.Response,
  next: express.NextFunction,
): void {
  const key = req.header('x-api-key');
  if (key !== env.API_KEY) {
    res.status(401).json({
      success: false,
      error: { code: 'UNAUTHENTICATED', message: 'Invalid or missing x-api-key' },
    });
    return;
  }
  next();
}

export function createMockApp(): express.Express {
  const app = express();
  const createdJobs: CreateProhireJobPayload[] = [];
  let lastSubmission: ClassificationResult[] | null = null;

  app.use(express.json({ limit: '100kb' }));
  app.use(requireApiKey);

  app.get('/api/v1/inbox/pull-latest', (_req, res) => {
    res.status(200).json(SAMPLE_EMAILS);
  });

  app.get('/api/v1/customers/by-reg-number', (req, res) => {
    const regRaw = typeof req.query['reg'] === 'string' ? req.query['reg'] : '';
    const reg = regRaw.replace(/\s+/gu, '').toUpperCase();
    const customer = CUSTOMERS[reg];
    if (!customer) {
      res.status(404).json({
        success: false,
        error: { code: 'RESOURCE_NOT_FOUND', message: 'Vehicle/customer not found' },
      });
      return;
    }
    res.status(200).json(customer);
  });

  app.post('/api/v1/jobs/new-prohire-job', (req, res) => {
    const body = req.body as CreateProhireJobPayload;
    const required = [
      'customer_name',
      'address',
      'phone',
      'vehicle_reg',
      'vehicle_type',
      'job_description',
    ] as const;

    for (const field of required) {
      if (typeof body[field] !== 'string' || body[field].trim() === '') {
        res.status(422).json({
          success: false,
          error: {
            code: 'VALIDATION_FAILED',
            message: `Missing or invalid field: ${field}`,
          },
        });
        return;
      }
    }

    createdJobs.push(body);
    res.status(201).json({
      success: true,
      data: {
        job_id: createdJobs.length,
        ...body,
      },
    });
  });

  app.post('/api/v1/results/submit', (req, res) => {
    const payload = req.body;
    if (!Array.isArray(payload) || payload.length === 0) {
      res.status(422).json({
        success: false,
        error: { code: 'VALIDATION_FAILED', message: 'Expected a non-empty results array' },
      });
      return;
    }

    lastSubmission = payload as ClassificationResult[];

    const expected: Record<number, string> = {
      101: 'new-defect',
      102: 'new-defect',
      103: 'enquiry',
      104: 'enquiry',
      105: 'junk-marketing',
      106: 'junk-marketing',
      107: 'malformed',
      108: 'malformed',
      109: 'new-defect',
      110: 'enquiry',
    };

    let correct = 0;
    for (const item of lastSubmission) {
      const id = Number(item.email_id);
      if (expected[id] === item.type) {
        correct += 1;
      }
    }

    const score = Math.round((correct / Object.keys(expected).length) * 100);
    res.status(200).json({
      success: true,
      score,
      correct,
      total: Object.keys(expected).length,
      jobs_created: createdJobs.length,
      message: `Scored ${score}/100 on classification accuracy`,
    });
  });

  app.get('/api/v1/debug/state', (_req, res) => {
    res.status(200).json({
      jobs: createdJobs,
      lastSubmission,
    });
  });

  return app;
}

export function startMockServer(port = env.MOCK_SERVER_PORT): Promise<ReturnType<typeof createServer>> {
  const app = createMockApp();
  const server = createServer(app);

  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, '127.0.0.1', () => {
      logger.info({ port }, 'Mock Prohire challenge API listening');
      resolve(server);
    });
  });
}

const isDirectRun =
  process.argv[1] !== undefined && import.meta.url === pathToFileURL(process.argv[1]).href;

if (isDirectRun) {
  startMockServer().catch((error: unknown) => {
    logger.error({ err: error }, 'Failed to start mock server');
    process.exitCode = 1;
  });
}

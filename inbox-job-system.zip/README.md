# Inbox → Job System

Node.js / TypeScript solution for the **Inbox → Job** practical exam.

It automates a back-office workflow for a UK commercial vehicle broker:

1. Pull the latest 10 emails  
2. Classify each email (`new-defect`, `enquiry`, `malformed`, `junk-marketing`)  
3. For every `new-defect`, extract the UK registration, look up the customer, and create a Prohire job  
4. Submit classification results to receive a score  

## Stack

- Node.js **24** (Active LTS)
- TypeScript (strict, ESM)
- Native `fetch`
- Zod validation
- Pino logging
- Express mock challenge API (local demo)

## Project layout

```text
src/
├── main.ts                          # Pipeline entrypoint
├── config/env.ts                    # Validated environment
├── common/
│   ├── errors/app-error.ts
│   └── observability/logger.ts
├── integrations/prohire/
│   ├── prohire.client.ts            # Challenge API client
│   └── prohire.types.ts
├── modules/inbox-job/
│   ├── classify-email.ts
│   ├── extract-registration.ts
│   ├── extract-defect-details.ts
│   └── process-inbox.service.ts
└── mock-server/server.ts            # Local API for offline demo
```

## Setup

```bash
cd inbox-job-system
cp .env.example .env
npm install
```

`.env` keys:

| Variable | Purpose |
|---|---|
| `API_BASE_URL` | Challenge API base URL |
| `API_KEY` | Value for `x-api-key` header |
| `HTTP_TIMEOUT_MS` | Request timeout |
| `MOCK_SERVER_PORT` | Local mock port (default `4090`) |

Exam defaults (from the brief):

```env
API_BASE_URL=https://challenge.prohire-software.com/api/v1
API_KEY=79C93322-89AF-48A3-8835-96144D58D849-01-M-Dever-Tester
```

## Run against the live exam API

```bash
npm start
```

## Run local demo (no live API required)

```bash
npm run demo
```

This starts an in-process mock of the challenge API, processes 10 sample emails, creates Prohire jobs for defects, submits results, and prints a score.

Optional: keep the mock API running separately:

```bash
npm run mock:server
# then in another terminal, set API_BASE_URL=http://127.0.0.1:4090/api/v1 and run:
npm start
```

## Tests / quality checks

```bash
npm test
npm run typecheck
npm run build
npm run check
```

## Classification rules (summary)

| Type | When |
|---|---|
| `malformed` | Empty body/subject, gibberish, unreadable content |
| `junk-marketing` | Newsletter / promo / unsubscribe language |
| `new-defect` | Vehicle fault / damage language (and usually a UK reg) |
| `enquiry` | Quotes, pricing, locations, hours, other questions |

UK registrations are extracted with current and common older formats (e.g. `GK20AOR`, `BX19 KLM`).

## API contract used

| Method | Path | Notes |
|---|---|---|
| `GET` | `/inbox/pull-latest` | Latest 10 emails |
| `GET` | `/customers/by-reg-number?reg=` | Customer + vehicle |
| `POST` | `/jobs/new-prohire-job` | Create defect job |
| `POST` | `/results/submit` | `[{ email_id, type }, ...]` |

All requests send:

```http
x-api-key: <API_KEY>
Accept: application/json
```

## Share with client

Zip the `inbox-job-system` folder **excluding** `node_modules` and `dist`, or share the folder after `npm install` verification:

```bash
npm run check
npm run demo
```

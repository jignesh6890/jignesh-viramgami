import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

import { extractUkRegistration, normalizeUkRegistration } from './extract-registration.js';

describe('extractUkRegistration', () => {
  it('extracts current-format registrations from subject/body', () => {
    assert.equal(
      extractUkRegistration('Issue with registration FG22ABC', 'please inspect'),
      'FG22ABC',
    );
    assert.equal(
      extractUkRegistration('Faulty indicator', 'van registration GK20AOR is faulty'),
      'GK20AOR',
    );
  });

  it('normalizes spaced registrations', () => {
    assert.equal(extractUkRegistration('Brake light on BX19 KLM'), 'BX19KLM');
    assert.equal(normalizeUkRegistration('gk20 aor'), 'GK20AOR');
  });

  it('returns null when no registration is present', () => {
    assert.equal(extractUkRegistration('Hello', 'Please send a quote'), null);
  });
});

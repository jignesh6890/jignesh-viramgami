import { logger } from '../../common/observability/logger.js';
import type { ProhireClient } from '../../integrations/prohire/prohire.client.js';
import type {
  ClassificationResult,
  InboxEmail,
} from '../../integrations/prohire/prohire.types.js';
import { classifyEmail } from './classify-email.js';
import { extractDefectDetails } from './extract-defect-details.js';
import { extractUkRegistration } from './extract-registration.js';

export interface ProcessInboxResult {
  classifications: ClassificationResult[];
  jobsCreated: number;
  jobsSkipped: number;
  submitResponse: unknown;
}

export function createProcessInboxService(client: ProhireClient) {
  async function processNewDefect(email: InboxEmail): Promise<boolean> {
    const registration = extractUkRegistration(email.subject, email.body);
    if (registration === null) {
      logger.warn({ emailId: email.id }, 'new-defect email missing registration; skipping job');
      return false;
    }

    const customer = await client.getCustomerByReg(registration);
    if (customer === null) {
      logger.warn(
        { emailId: email.id, registration },
        'Customer lookup failed; skipping Prohire job',
      );
      return false;
    }

    const jobDescription = extractDefectDetails(email.body, email.subject);

    await client.createProhireJob({
      customer_name: customer.customer_name,
      address: customer.address,
      phone: customer.phone,
      vehicle_reg: customer.vehicle_reg || registration,
      vehicle_type: customer.vehicle_type,
      job_description: jobDescription,
    });

    logger.info(
      { emailId: email.id, registration, customer: customer.customer_name },
      'Created Prohire job',
    );
    return true;
  }

  async function run(emails?: InboxEmail[]): Promise<ProcessInboxResult> {
    const inbox = emails ?? (await client.pullLatestInbox());
    const classifications: ClassificationResult[] = [];
    let jobsCreated = 0;
    let jobsSkipped = 0;

    for (const email of inbox) {
      const type = classifyEmail(email);
      classifications.push({
        email_id: email.id,
        type,
      });

      logger.info(
        {
          emailId: email.id,
          type,
          subject: email.subject,
        },
        'Classified email',
      );

      if (type !== 'new-defect') {
        continue;
      }

      try {
        const created = await processNewDefect(email);
        if (created) {
          jobsCreated += 1;
        } else {
          jobsSkipped += 1;
        }
      } catch (error: unknown) {
        jobsSkipped += 1;
        logger.error(
          { err: error, emailId: email.id },
          'Failed to create Prohire job for new-defect email',
        );
      }
    }

    const submitResponse = await client.submitResults(classifications);

    return {
      classifications,
      jobsCreated,
      jobsSkipped,
      submitResponse,
    };
  }

  return { run };
}

export type ProcessInboxService = ReturnType<typeof createProcessInboxService>;

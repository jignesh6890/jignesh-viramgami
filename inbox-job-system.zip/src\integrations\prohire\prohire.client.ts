import { env } from '../../config/env.js';
import { DependencyError } from '../../common/errors/app-error.js';
import { logger } from '../../common/observability/logger.js';
import {
  createProhireJobSchema,
  customerByRegSchema,
  inboxEmailSchema,
  submitResultsSchema,
  type CreateProhireJobPayload,
  type CustomerByReg,
  type InboxEmail,
  type SubmitResultsPayload,
} from './prohire.types.js';

type HttpMethod = 'GET' | 'POST';

export interface ProhireClient {
  pullLatestInbox(): Promise<InboxEmail[]>;
  getCustomerByReg(reg: string): Promise<CustomerByReg | null>;
  createProhireJob(payload: CreateProhireJobPayload): Promise<unknown>;
  submitResults(payload: SubmitResultsPayload): Promise<unknown>;
}

export function createProhireClient(
  options: {
    baseUrl?: string;
    apiKey?: string;
    timeoutMs?: number;
  } = {},
): ProhireClient {
  const baseUrl = (options.baseUrl ?? env.API_BASE_URL).replace(/\/$/u, '');
  const apiKey = options.apiKey ?? env.API_KEY;
  const timeoutMs = options.timeoutMs ?? env.HTTP_TIMEOUT_MS;

  async function request<T>(
    method: HttpMethod,
    path: string,
    schema: { parse: (data: unknown) => T },
    body?: unknown,
  ): Promise<T> {
    const url = `${baseUrl}${path}`;
    const headers: Record<string, string> = {
      Accept: 'application/json',
      'x-api-key': apiKey,
    };

    if (body !== undefined) {
      headers['Content-Type'] = 'application/json';
    }

    let response: Response;
    try {
      const init: RequestInit = {
        method,
        headers,
        signal: AbortSignal.timeout(timeoutMs),
      };

      if (body !== undefined) {
        init.body = JSON.stringify(body);
      }

      response = await fetch(url, init);
    } catch (error: unknown) {
      throw new DependencyError('PROHIRE_NETWORK_ERROR', { url, method }, { cause: error });
    }

    const text = await response.text();
    let json: unknown = null;
    if (text.length > 0) {
      try {
        json = JSON.parse(text) as unknown;
      } catch (error: unknown) {
        throw new DependencyError(
          'PROHIRE_INVALID_JSON',
          { url, method, status: response.status, body: text.slice(0, 500) },
          { cause: error },
        );
      }
    }

    if (!response.ok) {
      throw new DependencyError('PROHIRE_HTTP_ERROR', {
        url,
        method,
        status: response.status,
        body: json ?? text.slice(0, 500),
      });
    }

    return schema.parse(json);
  }

  return {
    async pullLatestInbox(): Promise<InboxEmail[]> {
      const data = await request('GET', '/inbox/pull-latest', {
        parse: (raw: unknown) => {
          const list = Array.isArray(raw)
            ? raw
            : raw !== null &&
                typeof raw === 'object' &&
                'emails' in raw &&
                Array.isArray((raw as { emails: unknown }).emails)
              ? (raw as { emails: unknown[] }).emails
              : null;

          if (list === null) {
            throw new DependencyError('PROHIRE_INBOX_SHAPE_INVALID', { raw });
          }

          return list.map((item) => inboxEmailSchema.parse(item));
        },
      });

      logger.info({ count: data.length }, 'Pulled latest inbox emails');
      return data.slice(0, 10);
    },

    async getCustomerByReg(reg: string): Promise<CustomerByReg | null> {
      const encoded = encodeURIComponent(reg);
      try {
        return await request(
          'GET',
          `/customers/by-reg-number?reg=${encoded}`,
          customerByRegSchema,
        );
      } catch (error: unknown) {
        if (error instanceof DependencyError && error.details !== undefined) {
          const details = error.details as { status?: number };
          if (details.status === 404) {
            logger.warn({ reg }, 'No customer found for registration');
            return null;
          }
        }
        throw error;
      }
    },

    async createProhireJob(payload: CreateProhireJobPayload): Promise<unknown> {
      const validated = createProhireJobSchema.parse(payload);
      return request('POST', '/jobs/new-prohire-job', {
        parse: (raw: unknown) => raw,
      }, validated);
    },

    async submitResults(payload: SubmitResultsPayload): Promise<unknown> {
      const validated = submitResultsSchema.parse(payload);
      return request('POST', '/results/submit', {
        parse: (raw: unknown) => raw,
      }, validated);
    },
  };
}

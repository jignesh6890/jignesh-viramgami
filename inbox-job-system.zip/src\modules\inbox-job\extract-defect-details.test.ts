import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

import { extractDefectDetails } from './extract-defect-details.js';

describe('extractDefectDetails', () => {
  it('returns a concise defect summary from the body', () => {
    const details = extractDefectDetails(
      'Hi, the wing mirror is cracked on FG22ABC and needs replacing.',
      'Issue with FG22ABC',
    );
    assert.match(details, /wing mirror is cracked/iu);
  });

  it('falls back to subject when body is empty', () => {
    assert.equal(extractDefectDetails('', 'Faulty indicator'), 'Faulty indicator');
  });
});

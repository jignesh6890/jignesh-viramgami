import { z } from 'zod';

export const EMAIL_CLASSIFICATIONS = [
  'new-defect',
  'enquiry',
  'malformed',
  'junk-marketing',
] as const;

export type EmailClassification = (typeof EMAIL_CLASSIFICATIONS)[number];

export const inboxEmailSchema = z.object({
  id: z.union([z.number().int(), z.string()]),
  from: z.string(),
  to: z.string(),
  subject: z.string(),
  body: z.string(),
  timestamp: z.string(),
});

export type InboxEmail = z.infer<typeof inboxEmailSchema>;

export const customerByRegSchema = z
  .object({
    customer_name: z.string(),
    address: z.string(),
    phone: z.string(),
    vehicle_reg: z.string(),
    vehicle_type: z.string(),
  })
  .passthrough();

export type CustomerByReg = z.infer<typeof customerByRegSchema>;

export const createProhireJobSchema = z.object({
  customer_name: z.string().min(1),
  address: z.string().min(1),
  phone: z.string().min(1),
  vehicle_reg: z.string().min(1),
  vehicle_type: z.string().min(1),
  job_description: z.string().min(1),
});

export type CreateProhireJobPayload = z.infer<typeof createProhireJobSchema>;

export const classificationResultSchema = z.object({
  email_id: z.union([z.number().int(), z.string()]),
  type: z.enum(EMAIL_CLASSIFICATIONS),
});

export type ClassificationResult = z.infer<typeof classificationResultSchema>;

export const submitResultsSchema = z.array(classificationResultSchema).min(1);

export type SubmitResultsPayload = z.infer<typeof submitResultsSchema>;

import assert from 'node:assert/strict';
import { after, before, describe, it } from 'node:test';

import { createProhireClient } from '../../integrations/prohire/prohire.client.js';
import { createProcessInboxService } from './process-inbox.service.js';
import { startMockServer } from '../../mock-server/server.js';
import { env } from '../../config/env.js';

describe('processInboxService (integration against mock API)', () => {
  let server: Awaited<ReturnType<typeof startMockServer>>;
  const port = 4091;

  before(async () => {
    server = await startMockServer(port);
  });

  after(async () => {
    await new Promise<void>((resolve, reject) => {
      server.close((error) => (error ? reject(error) : resolve()));
    });
  });

  it('classifies emails, creates defect jobs, and submits results', async () => {
    const client = createProhireClient({
      baseUrl: `http://127.0.0.1:${port}/api/v1`,
      apiKey: env.API_KEY,
      timeoutMs: 5_000,
    });

    const service = createProcessInboxService(client);
    const result = await service.run();

    assert.equal(result.classifications.length, 10);
    assert.equal(result.jobsCreated, 3);

    const byId = new Map(result.classifications.map((item) => [Number(item.email_id), item.type]));
    assert.equal(byId.get(101), 'new-defect');
    assert.equal(byId.get(102), 'new-defect');
    assert.equal(byId.get(105), 'junk-marketing');
    assert.equal(byId.get(107), 'malformed');

    const submit = result.submitResponse as { score?: number };
    assert.equal(submit.score, 100);
  });
});

import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';

import { z } from 'zod';

const envSchema = z.object({
  API_BASE_URL: z
    .string()
    .url()
    .default('https://challenge.prohire-software.com/api/v1'),
  API_KEY: z.string().min(1),
  HTTP_TIMEOUT_MS: z.coerce.number().int().positive().default(15_000),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace']).default('info'),
  MOCK_SERVER_PORT: z.coerce.number().int().min(1).max(65_535).default(4090),
});

export type Env = z.infer<typeof envSchema>;

function loadDotEnvFile(): void {
  const envPath = resolve(process.cwd(), '.env');
  if (!existsSync(envPath)) {
    return;
  }

  const raw = readFileSync(envPath, 'utf8');
  for (const line of raw.split(/\r?\n/u)) {
    const trimmed = line.trim();
    if (trimmed === '' || trimmed.startsWith('#')) {
      continue;
    }

    const eq = trimmed.indexOf('=');
    if (eq <= 0) {
      continue;
    }

    const key = trimmed.slice(0, eq).trim();
    let value = trimmed.slice(eq + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }

    if (process.env[key] === undefined) {
      process.env[key] = value;
    }
  }
}

loadDotEnvFile();

export const env: Env = envSchema.parse({
  API_BASE_URL: process.env['API_BASE_URL'],
  API_KEY: process.env['API_KEY'],
  HTTP_TIMEOUT_MS: process.env['HTTP_TIMEOUT_MS'],
  LOG_LEVEL: process.env['LOG_LEVEL'],
  MOCK_SERVER_PORT: process.env['MOCK_SERVER_PORT'],
});

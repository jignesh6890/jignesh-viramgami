import type { EmailClassification } from '../../integrations/prohire/prohire.types.js';
import { extractUkRegistration } from './extract-registration.js';

export interface ClassifiableEmail {
  subject: string;
  body: string;
  from?: string;
}

const DEFECT_KEYWORDS = [
  'defect',
  'fault',
  'faulty',
  'broken',
  'damage',
  'damaged',
  'cracked',
  'leak',
  'leaking',
  'not working',
  "doesn't work",
  'does not work',
  'failed',
  'failure',
  'issue with',
  'problem with',
  'warning light',
  'brake',
  'tyre',
  'tire',
  'mirror',
  'indicator',
  'windscreen',
  'engine',
  'clutch',
  'gearbox',
  'exhaust',
  'battery',
  'overheating',
  'smoke',
] as const;

const ENQUIRY_KEYWORDS = [
  'quote',
  'pricing',
  'price',
  'cost',
  'how much',
  'availability',
  'available',
  'location',
  'opening hours',
  'where are you',
  'enquiry',
  'inquiry',
  'question',
  'cover for',
  'insurance for',
  'can you help',
  'please advise',
  'information about',
] as const;

const MARKETING_KEYWORDS = [
  'unsubscribe',
  'newsletter',
  'special offer',
  'limited time',
  'click here',
  'buy now',
  'discount',
  'promo',
  'promotion',
  'marketing',
  'sale ends',
  'free trial',
  'congratulations you have won',
  'act now',
  'webinar',
] as const;

function normalize(text: string): string {
  return text.replace(/\s+/gu, ' ').trim().toLowerCase();
}

function containsAny(haystack: string, needles: readonly string[]): boolean {
  return needles.some((needle) => haystack.includes(needle));
}

function isMostlyGibberish(text: string): boolean {
  const compact = text.replace(/\s+/gu, '');
  if (compact.length === 0) {
    return true;
  }

  if (compact.length < 8) {
    return true;
  }

  const letters = (compact.match(/[a-z]/giu) ?? []).length;
  const letterRatio = letters / compact.length;
  if (letterRatio < 0.45) {
    return true;
  }

  // Repeated nonsense tokens / keyboard smash
  if (/^(.)\1{6,}$/u.test(compact)) {
    return true;
  }

  const uniqueRatio = new Set(compact.toLowerCase().split('')).size / compact.length;
  if (compact.length > 20 && uniqueRatio < 0.2) {
    return true;
  }

  return false;
}

/**
 * Classify an inbox email into one of the four challenge categories.
 * Order: malformed → junk-marketing → new-defect → enquiry (default for remaining).
 */
export function classifyEmail(email: ClassifiableEmail): EmailClassification {
  const subject = email.subject ?? '';
  const body = email.body ?? '';
  const combined = normalize(`${subject}\n${body}`);

  if (isMostlyGibberish(body) || (subject.trim() === '' && body.trim() === '')) {
    return 'malformed';
  }

  if (containsAny(combined, MARKETING_KEYWORDS)) {
    return 'junk-marketing';
  }

  const hasReg = extractUkRegistration(subject, body) !== null;
  const hasDefectLanguage = containsAny(combined, DEFECT_KEYWORDS);

  if (hasDefectLanguage) {
    return 'new-defect';
  }

  // Registration + vehicle problem phrasing without an explicit keyword list hit.
  if (
    hasReg &&
    /\b(van|vehicle|truck|lorry|fleet|hire)\b/iu.test(combined) &&
    /\b(issue|problem|fault|broken|damage|not working)\b/iu.test(combined)
  ) {
    return 'new-defect';
  }

  if (containsAny(combined, ENQUIRY_KEYWORDS) || combined.includes('?')) {
    return 'enquiry';
  }

  // Default remaining business correspondence to enquiry rather than marketing.
  return 'enquiry';
}

import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

import { classifyEmail } from './classify-email.js';

describe('classifyEmail', () => {
  it('classifies new vehicle defects', () => {
    assert.equal(
      classifyEmail({
        subject: 'Faulty indicator on van GK20AOR',
        body: 'The near-side indicator is faulty and not flashing.',
      }),
      'new-defect',
    );
  });

  it('classifies enquiries', () => {
    assert.equal(
      classifyEmail({
        subject: 'Quote for additional vans',
        body: 'Could you send pricing and availability for next month?',
      }),
      'enquiry',
    );
  });

  it('classifies junk marketing', () => {
    assert.equal(
      classifyEmail({
        subject: 'Limited time special offer',
        body: 'Click here for a discount. Unsubscribe anytime.',
      }),
      'junk-marketing',
    );
  });

  it('classifies malformed empty messages', () => {
    assert.equal(classifyEmail({ subject: '', body: '' }), 'malformed');
  });

  it('classifies gibberish as malformed', () => {
    assert.equal(
      classifyEmail({
        subject: 'asdf',
        body: '%%%%####@@@@ ~~~~ qqqqqqqqqqqqqqqqqqq',
      }),
      'malformed',
    );
  });
});

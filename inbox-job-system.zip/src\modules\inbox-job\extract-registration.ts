/**
 * UK vehicle registration patterns (current + common older formats).
 * Example current format: GK20AOR
 */
const UK_REG_PATTERNS: readonly RegExp[] = [
  // Current (2001+): AA99AAA
  /\b([A-Z]{2}\d{2}\s?[A-Z]{3})\b/giu,
  // Prefix (1983–2001): A999AAA / A99AAA / A9AAA
  /\b([A-Z]\d{1,3}\s?[A-Z]{3})\b/giu,
  // Suffix (1963–1983): AAA999A / AAA99A / AAA9A
  /\b([A-Z]{3}\s?\d{1,3}[A-Z])\b/giu,
];

export function normalizeUkRegistration(value: string): string {
  return value.replace(/\s+/gu, '').toUpperCase();
}

export function extractUkRegistration(...texts: string[]): string | null {
  const haystack = texts.filter((t) => typeof t === 'string' && t.trim() !== '').join('\n');
  if (haystack.trim() === '') {
    return null;
  }

  for (const pattern of UK_REG_PATTERNS) {
    pattern.lastIndex = 0;
    const match = pattern.exec(haystack);
    if (match?.[1]) {
      return normalizeUkRegistration(match[1]);
    }
  }

  return null;
}

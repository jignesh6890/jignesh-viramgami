export class AppError extends Error {
  constructor(
    public readonly code: string,
    public readonly status: number,
    message: string,
    public readonly details?: unknown,
    options?: ErrorOptions,
  ) {
    super(message, options);
    this.name = new.target.name;
  }
}

export class DependencyError extends AppError {
  constructor(code: string, details?: unknown, options?: ErrorOptions) {
    super(code, 502, 'Upstream dependency failed', details, options);
  }
}

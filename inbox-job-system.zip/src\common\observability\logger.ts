import pino from 'pino';

import { env } from '../../config/env.js';

export const logger = pino({
  level: env.LOG_LEVEL,
  base: {
    service: 'inbox-job-system',
  },
  redact: {
    paths: ['apiKey', 'req.headers["x-api-key"]', 'headers["x-api-key"]'],
    censor: '[Redacted]',
  },
});
